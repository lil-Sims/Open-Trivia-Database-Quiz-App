# Open Trivia Database Quiz App

A Pen created on CodePen.

Original URL: [https://codepen.io/khalilcodex/pen/YPqZOqY](https://codepen.io/khalilcodex/pen/YPqZOqY).

