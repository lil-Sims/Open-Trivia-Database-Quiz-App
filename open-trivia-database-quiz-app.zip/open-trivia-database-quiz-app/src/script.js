let state = {
  username: "",
  category: "",
  difficulty: "",
  currentQuestion: null,
  correctAnswer: ""
};

const homeSection = document.getElementById("home");
const questionSection = document.getElementById("question");
const resultsSection = document.getElementById("results");

const setupForm = document.getElementById("setupForm");
const formError = document.getElementById("formError");

const questionText = document.getElementById("questionText");
const answersDiv = document.getElementById("answers");
const questionForm = document.getElementById("questionForm");
const questionError = document.getElementById("questionError");
const apiError = document.getElementById("apiError");

const resultMessage = document.getElementById("resultMessage");
const correctAnswerMsg = document.getElementById("correctAnswer");
const restartBtn = document.getElementById("restartBtn");

// Handle setup form submit
setupForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  formError.textContent = "";

  const username = document.getElementById("username").value.trim();
  const category = document.getElementById("category").value;
  const difficulty = document.getElementById("difficulty").value;

  if (!username || !category || !difficulty) {
    formError.textContent = "All fields are required!";
    return;
  }

  state.username = username;
  state.category = category;
  state.difficulty = difficulty;

  try {
    const url = `https://opentdb.com/api.php?amount=1&category=${category}&difficulty=${difficulty}&type=multiple`;
    const res = await fetch(url);
    const data = await res.json();

    if (data.response_code !== 0) {
      apiError.textContent = "Error fetching question. Try again!";
      return;
    }

    state.currentQuestion = data.results[0];
    state.correctAnswer = state.currentQuestion.correct_answer;

    showQuestion();
  } catch (err) {
    apiError.textContent = "API error. Please try again later.";
  }
});

function showQuestion() {
  homeSection.classList.add("hidden");
  questionSection.classList.remove("hidden");

  questionText.innerHTML = state.currentQuestion.question;

  const answers = [...state.currentQuestion.incorrect_answers, state.currentQuestion.correct_answer];
  shuffleArray(answers);

  answersDiv.innerHTML = "";
  answers.forEach((answer, index) => {
    const option = document.createElement("div");
    option.innerHTML = `
      <input type="radio" id="answer${index}" name="answer" value="${answer}">
      <label for="answer${index}">${answer}</label>
    `;
    answersDiv.appendChild(option);
  });
}

questionForm.addEventListener("submit", (e) => {
  e.preventDefault();
  questionError.textContent = "";

  const selected = document.querySelector('input[name="answer"]:checked');
  if (!selected) {
    questionError.textContent = "Please select an answer!";
    return;
  }

  const userAnswer = selected.value;
  showResults(userAnswer);
});

function showResults(userAnswer) {
  questionSection.classList.add("hidden");
  resultsSection.classList.remove("hidden");

  if (userAnswer === state.correctAnswer) {
    resultMessage.textContent = `🎉 Well done, ${state.username}! You got it right!`;
    correctAnswerMsg.textContent = "";
  } else {
    resultMessage.textContent = `😢 Sorry, ${state.username}. That was incorrect.`;
    correctAnswerMsg.textContent = `The correct answer was: ${state.correctAnswer}`;
  }
}

restartBtn.addEventListener("click", () => {
  resultsSection.classList.add("hidden");
  homeSection.classList.remove("hidden");
  setupForm.reset();
});

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}
